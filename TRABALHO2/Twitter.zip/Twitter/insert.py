

arq = open('dados_twitter_doenca.txt', 'r')
linha = arq.readline()
lst=[]
while linha !='':
    text = " insert into Twitter (texto, data, cod_pesquisa) values ('"+linha+"', '2016/12/11', 4);"
    if text not in lst:
        lst.append(text)
    linha = arq.readline()
arq.close()
tam = len(lst)
x = 0
arq = open("insert_doenca.txt", 'w')
while x < tam:
    print(lst[x])
    arq.write(lst[x]+'\n')
    x+=1
arq.close()

