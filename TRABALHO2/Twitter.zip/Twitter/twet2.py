# encoding: utf-8
# encoding: iso-8859-1
# encoding: win-1252

import codecs

import tweepy

import psycopg2

import sqlalchemy


#definição dos tokens de acesso
access_token = '807219604573528064-Bdv5A0jO9vBeOFlnyiKtFpbabYFgB6b'
access_token_secret = 'rrrHS0SPt0SoIgksjoYhlQQnqrExaC1YFPXts3t703zaU'
consumer_key = 'FPF0zZA3JiiMUC52VBHwbNMrm'
consumer_secret = 'ngGzeiGp1QY0iMyTlK0uxpbwh2x2AwNJ2UH0ZALUWqDtOItORx'

#autenticção dos tokens
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)

api = tweepy.API(auth)
#Abrindo aquivo para escrita
arq = codecs.open('dados_twitter_epidemia.txt', 'w','utf-8')
lst=[]
#buscando por termos referentes ao trabalho.
for tweet in tweepy.Cursor(api.search, q="casos de epidemia", result_type="recent",lang="pt").items(1000):
    print tweet.created_at, tweet.text
    arq.write(tweet.text+'\n')
    lst.append(tweet.text+'\n')

arq.close()

