import psycopg2

import sqlalchemy

from sqlalchemy import create_engine

engine = create_engine("postgresql://postgres:1001@localhost/SUS++")
conn = engine.connect()

result = conn.execute('select * from pesquisa;')
valores = result.fetchall()
for linha in valores:
    print(linha)

print(conn)